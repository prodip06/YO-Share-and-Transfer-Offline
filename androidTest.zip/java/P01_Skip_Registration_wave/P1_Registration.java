package P01_Skip_Registration_wave;

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;
import com.bitbar.recorder.extensions.ExtSolo;
import com.lotd.yoapp.R;
import junit.framework.AssertionFailedError;
import P00_DataInput.DataInput;

public class P1_Registration extends ActivityInstrumentationTestCase2<Activity> {

    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.lotd.yoapp.YoSplash";
    private static Class<?> launchActivityClass;
    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    private ExtSolo solo; // ExtSolo is an extension of Robotium Solo that helps collecting better test execution data during test runs

    @SuppressWarnings("unchecked")
    public P1_Registration() {
        super((Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass().getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }

    public void testRecorded() throws Exception {
        try {
            solo.waitForActivity("YoSplash");
            solo.sleep(100);

            solo.clickOnText("GET CONNECTED!");
            solo.sleep(100);

            assertTrue(
                    "Wait for button (id: com.lotd.yoapp.R.id.btnCreateProfile) failed.",
                    solo.waitForButtonById("com.lotd.yoapp.R.id.btnCreateProfile", 2000));
            solo.clickOnButton((Button) solo.findViewById("com.lotd.yoapp.R.id.btnCreateProfile"));
            solo.sleep(3100);

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.txt_name) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.txt_name", 2000));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.txt_name"), DataInput.ProfileName);

            solo.clickOnView(solo.getView(R.id.itemEdit));
            solo.sleep(860);

            solo.clickOnText("SKIP");
            solo.sleep(8000);

            int screenWidth = getActivity().getWindowManager().getDefaultDisplay().getWidth();
            int screenHeight = getActivity().getWindowManager().getDefaultDisplay().getHeight();
            int fromX, toX, fromY, toY = 0;
            fromX = screenWidth/2;
            toX = screenWidth/2;
            fromY = (screenHeight/2) + (screenHeight/3);
            toY = (screenHeight/2) - (screenHeight/3);
            int scroll_time = 60000;
            solo.sleep(5000);
            // Drag UP
            solo.drag(fromX, toX, fromY, toY, 40);
            solo.drag(toX, fromX, toY, fromY, 50);
            solo.sleep(8370);

           /* solo.clickOnText("Try it out!");
            solo.sleep(100);

            solo.clickOnText("Yeah, i'm good");
            solo.sleep(100);

            solo.clickOnText("YO!");
            solo.sleep(2000);

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.button_publish) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.button_publish", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.button_publish"));

            solo.clickOnText("POST IT!");
            solo.sleep(7000);

            solo.clickOnText("All done - get exploring!");
            solo.sleep(8000);*/


        }

        catch (AssertionFailedError e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest1.testRecorded_scr_fail", e);
            throw e;

        } catch (Exception e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest1.testRecorded_scr_fail", e);
            throw e;
        }
    }

}
