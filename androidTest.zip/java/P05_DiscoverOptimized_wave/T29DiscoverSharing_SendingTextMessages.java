package P05_DiscoverOptimized_wave;
/**
 * Test Automation by Prodip Biswas 04 April,2016
 */

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.bitbar.recorder.extensions.ExtSolo;
import com.lotd.yoapp.R;

import junit.framework.AssertionFailedError;
/**
 * Test Automation by Prodip Biswas 01 April, 2016
 */

public class T29DiscoverSharing_SendingTextMessages extends ActivityInstrumentationTestCase2<Activity> {
    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.lotd.yoapp.YoSplash";
    private static Class<?> launchActivityClass;

    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private ExtSolo solo;

    @SuppressWarnings("unchecked")
    public T29DiscoverSharing_SendingTextMessages() {
        super((Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass()
                .getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }

    public void testCase29_SendingInternetTextMessages() throws Exception {
        try {
            solo.waitForActivity("YoSplash");
            solo.sleep(3000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnText("friends");
            solo.sleep(500);

            solo.clickLongOnText("NOMAN");
            solo.sleep(1500);

          /*View view = solo.getView("profileName");
            solo.clickOnView(view);
            solo.sleep(500);*/

            solo.waitForActivity("MessageActivity");
            for (int i = 0; i <= 2; i++) {
                solo.sleep(90);
                assertTrue(
                        "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                        solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 1000));
                solo.enterText((EditText)
                        solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is Automated Message,Plz dont mind and ignore this message");
                assertTrue(
                        "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                        solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 1000));
                solo.clickOnImageButton((ImageButton)
                        solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
                solo.sleep(1);

            }

            solo.goBack();
            solo.sleep(1000);

            /*View view2 = solo.getView("profileName");
            solo.clickOnView(view2);
            solo.sleep(500)*/;

            solo.clickLongOnText("NOMAN");
            solo.sleep(1500);

       /*   View view2nn = solo.getView("profileName");
            solo.clickOnView(view2nn);
            solo.sleep(500);*/

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Hi");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "How Are You");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is from Test Automation Message");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));


            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Start Sharing");

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(500);

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonPlus) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonPlus", 10));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonPlus"));
            solo.sleep(10);
            solo.clickOnScreen(357, 905);
            solo.sleep(90);

            solo.clickLongInList(2, 0, 1000);
            //solo.clickLongInList(3, 0, 1000);

            solo.clickOnText("Share");
            solo.sleep(15000);
            /*
            solo.waitForActivity("MessageActivity");
            solo.sleep(140);*/

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo
                    .findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Done");
            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            solo.goBack();
            solo.sleep(1000);

            solo.goBack();
            solo.sleep(1000);

       /*   View view3 = solo.getView("profileName");
            solo.clickOnView(view3);
            solo.sleep(500);  */



            solo.clickLongOnText("NOMAN");
            solo.sleep(150);


            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.edt_type_sms) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Hi");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.edt_type_sms) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "How Are You");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is from Test Automation Message");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Start Sharing");

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(500);

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonPlus) failed.",
                    solo.waitForImageButtonById(
                            "com.lotd.yoapp.R.id.imageButtonPlus", 10));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonPlus"));
            solo.sleep(10);

            assertTrue(
                    "Wait for button (id: com.lotd.yoapp.R.id.btnRecord) failed.",
                    solo.waitForButtonById("com.lotd.yoapp.R.id.btnRecord", 200));
            solo.clickOnButton((Button)
                    solo.findViewById("com.lotd.yoapp.R.id.btnRecord"));
            solo.sleep(990);


            assertTrue(
                    "Wait for button (id: com.lotd.yoapp.R.id.recorderButton) failed.",
                    solo.waitForButtonById("com.lotd.yoapp.R.id.recorderButton", 200));
            Button myBtn = (Button) solo.getView(R.id.recorderButton);
            solo.clickLongOnButton(myBtn, 15000);
            solo.sleep(9000);


            /*solo.waitForActivity("MessageActivity");
            solo.sleep(140);*/

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Done");

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));


            solo.goBack();
            solo.sleep(1000);

            solo.goBack();
            solo.sleep(1000);

     /*     View view4 = solo.getView("profileName");
            solo.clickOnView(view4);
            solo.sleep(500);*/

            solo.clickLongOnText("NOMAN");
            solo.sleep(1500);

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Hi");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "How Are You");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is from Test Automation Message");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));


            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Start Sharing");

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(500);

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonPlus) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonPlus", 100));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonPlus"));
            solo.sleep(100);


            assertTrue(
                    "Wait for button (id: com.lotd.yoapp.R.id.btnMusic) failed.",
                    solo.waitForButtonById("com.lotd.yoapp.R.id.btnMusic", 200));
            solo.clickOnButton((Button)
                    solo.findViewById("com.lotd.yoapp.R.id.btnMusic"));
            solo.sleep(990);


            assertTrue("Wait for list (index: 0) failed.",
                    solo.waitForList(0, 200));
            solo.clickInList(2, 0);
            solo.sleep(380);
            solo.clickOnText("Share");
            solo.sleep(5000);

            solo.waitForActivity("MessageActivity");
            solo.sleep(140);

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Done");
            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.goBack();
            solo.sleep(1000);

            solo.goBack();
            solo.sleep(1000);

            /*View view5 = solo.getView("profileName");
            solo.clickOnView(view5);
            solo.sleep(500);*/

            solo.clickLongOnText("NOMAN");
            solo.sleep(1500);

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Hi");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "How Are You");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is from Test Automation Message");

            assertTrue(
                    "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));


            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText)
                    solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Start Sharing");

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(500);

            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonPlus) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonPlus", 1000));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonPlus"));
            solo.sleep(1000);


            assertTrue(
                    "Wait for button (id: com.lotd.yoapp.R.id.btnFile) failed.",
                    solo.waitForButtonById("com.lotd.yoapp.R.id.btnFile", 200));
            solo.clickOnButton((Button)
                    solo.findViewById("com.lotd.yoapp.R.id.btnFile"));
            solo.waitForActivity("FileManagerActivity");
            solo.sleep(2000);
            solo.clickOnText("Android Applications");
            solo.sleep(520);
            solo.clickOnImage(3);
            solo.sleep(520);

            solo.clickOnText("Share");
            solo.sleep(35000);

            solo.waitForActivity("MessageActivity");
            solo.sleep(1400);

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo
                    .findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Done");
            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                    solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton)
                    solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            solo.goBack();
            solo.sleep(1000);

            //Internet Online or Offline Checking
          /* for (int k = 2; k<=4; k++) {
            RecyclerView myList = (RecyclerView) solo.getView(R.id.contacts_recycler_view);
            View listElement = myList.getChildAt(k);
            View rightimage=listElement.findViewById(R.id.profileName);
            solo.clickOnView(rightimage);
            solo.sleep(500);*//*

            View view6 = solo.getView("profileName");
            solo.clickOnView(view6);
            solo.sleep(500);

            solo.waitForActivity("MessageActivity");

            for (int i = 0; i <= 5; i++) {
            solo.sleep(90);
            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 1));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Internet Status now: "+ YoTestAutomation.OnlineOfflineResult);
            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 1));
            solo.clickOnImageButton((ImageButton)
            solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(1);
                }
           *//**//* solo.goBack();
            }*//**//*
            solo.goBack();
            solo.sleep(500);*/


            // View view1n = solo.getView("profileName");
            // solo.clickOnView(view1n);
            //solo.sleep(500);

            //Internet Online or Offline Checking
           /* for (int k = 2; k<=4; k++) {
            RecyclerView myList = (RecyclerView) solo.getView(R.id.contacts_recycler_view);
            View listElement = myList.getChildAt(k);
            View rightimage=listElement.findViewById(R.id.profileName);
            solo.clickOnView(rightimage);
            solo.sleep(500);

          View view6 = solo.getView("profileName");
            solo.clickOnView(view6);
            solo.sleep(500);

            solo.waitForActivity("YoConversationActivity");

            for (int i = 0; i <= 5; i++) {
            solo.sleep(90);
            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 1));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Internet Status now: "+ YoTestAutomation.OnlineOfflineResult);
            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 1));
            solo.clickOnImageButton((ImageButton)
            solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(1);
                }
           *//**//* solo.goBack();
            }*//**//*
            solo.goBack();
            solo.sleep(500);*/

//............................................................



            // View view1n = solo.getView("profileName");
            // solo.clickOnView(view1n);
            //solo.sleep(500);

           /* solo.clickLongOnText("Tania");
            solo.sleep(1500);

            solo.waitForActivity("MessageActivity");
            for (int i = 0; i <= 2; i++) {
                assertTrue("Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 1000));
                solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Automated Message,Plz ignore the message");
                assertTrue("Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 1000));
                solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
                solo.sleep(1);
            }

        *//*  solo.goBack();
            solo.sleep(1000);

            View view2 = solo.getView("profileName");
            solo.clickOnView(view2);
            solo.sleep(500);*//*

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.edit_type_sms) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Hi");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.edt_type_sms) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "How Are You");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is from Test Automation Message");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));


            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Start Sharing");

            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(500);

            //image sending start
            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonPlus) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonPlus", 10));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonPlus"));
            solo.sleep(10);

            solo.clickOnScreen(357, 905);
            solo.sleep(90);

            solo.clickLongInList(2, 0, 1000);
        //  solo.clickLongInList(3, 0, 1000);

            solo.clickOnText("Share");
            solo.sleep(15000);
            solo.waitForActivity("MessageActivity");
            solo.sleep(140);

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Done");
            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            //image sending end

         *//* solo.goBack();
            solo.sleep(1000);
            View view3 = solo.getView("profileName");
            solo.clickOnView(view3);
            solo.sleep(500);*//*

            //Record File sending start
            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Hi");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "How Are You");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is from Test Automation Message");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Start Sharing");

            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(500);

            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonPlus) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonPlus", 10));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonPlus"));
            solo.sleep(10);

            assertTrue("Wait for button (id: com.lotd.yoapp.R.id.btnRecord) failed.",
            solo.waitForButtonById("com.lotd.yoapp.R.id.btnRecord", 200));
            solo.clickOnButton((Button) solo.findViewById("com.lotd.yoapp.R.id.btnRecord"));
            solo.sleep(990);

            assertTrue("Wait for button (id: com.lotd.yoapp.R.id.recorderButton) failed.",
            solo.waitForButtonById("com.lotd.yoapp.R.id.recorderButton", 200));
            Button myBtn = (Button) solo.getView(R.id.recorderButton);
            solo.clickLongOnButton(myBtn, 15000);
            solo.sleep(9000);

            solo.waitForActivity("MessageActivity");
            solo.sleep(140);

            assertTrue("Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Done");
            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton)
            solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            //Record File sending end

            *//**
             solo.goBack();
             solo.sleep(1000);

             View view4 = solo.getView("profileName");
             solo.clickOnView(view4);
             solo.sleep(500);*//*

          // Music File sending start
            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Hi");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "How Are You");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is from Test Automation Message");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));


            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Start Sharing");

            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
            solo.sleep(500);

            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonPlus) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonPlus", 100));
            solo.clickOnImageButton((ImageButton)solo.findViewById("com.lotd.yoapp.R.id.imageButtonPlus"));
            solo.sleep(100);


            assertTrue(
            "Wait for button (id: com.lotd.yoapp.R.id.btnMusic) failed.",
            solo.waitForButtonById("com.lotd.yoapp.R.id.btnMusic", 200));
            solo.clickOnButton((Button) solo.findViewById("com.lotd.yoapp.R.id.btnMusic"));
            solo.sleep(990);


            assertTrue("Wait for list (index: 0) failed.",
            solo.waitForList(0, 200));
            solo.clickInList(2, 0);
            solo.sleep(380);
            solo.clickOnText("Share");
            solo.sleep(5000);

            solo.waitForActivity("MessageActivity");
            solo.sleep(140);

            assertTrue("Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Done");
            assertTrue("Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton)
            solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            // Music File sending end


         *//* solo.goBack();
            solo.sleep(1000);

            View view5 = solo.getView("profileName");
            solo.clickOnView(view5);
            solo.sleep(500);*//*

            //  pdf File sharing start
            assertTrue("Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Hi");

            assertTrue(
            "Wait for imagebutton (id: com.lotd.yoapp.R.id.imagebtnSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imagebtnSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imagebtnSend"));

            assertTrue(
            "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "How Are You");

            assertTrue("Wait for imagebutton (id: com.lotd.yoapp.R.id.imagebtnSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imagebtnSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imagebtnSend"));

            assertTrue("Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is from Test Automation Message");

            assertTrue("Wait for imagebutton (id: com.lotd.yoapp.R.id.imagebtnSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imagebtnSend", 120));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imagebtnSend"));


            assertTrue("Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Start Sharing");

            assertTrue(
            "Wait for image button (id: com.lotd.yoapp.R.id.imagebtnSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imagebtnSend", 200));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imagebtnSend"));
            solo.sleep(500);

            assertTrue("Wait for image button (id: com.lotd.yoapp.R.id.imageButtonPlus) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonPlus", 1000));
            solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonPlus"));
            solo.sleep(1000);


            assertTrue(
            "Wait for button (id: com.lotd.yoapp.R.id.btnFile) failed.",
            solo.waitForButtonById("com.lotd.yoapp.R.id.btnFile", 200));
            solo.clickOnButton((Button) solo.findViewById("com.lotd.yoapp.R.id.btnFile"));
            solo.waitForActivity("FileManagerActivity");
            solo.sleep(2000);
            solo.clickOnText("Android Applications");
            solo.sleep(520);
            solo.clickOnImage(3);
            solo.sleep(1520);

            solo.clickOnText("Share");
            solo.sleep(35000);

            solo.waitForActivity("MessageActivity");
            solo.sleep(1400);

            assertTrue("Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Done");
            assertTrue("Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 200));
            solo.clickOnImageButton((ImageButton)
            solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));

            solo.goBack();
            solo.sleep(1000);
            //  pdf File sharing end

            //Internet Online or Offline Checking
           *//* for (int k = 2; k<=4; k++) {
            RecyclerView myList = (RecyclerView) solo.getView(R.id.contacts_recycler_view);
            View listElement = myList.getChildAt(k);
            View rightimage=listElement.findViewById(R.id.profileName);
            solo.clickOnView(rightimage);
            solo.sleep(500);*//*

        *//*  View view6 = solo.getView("profileName");
            solo.clickOnView(view6);
            solo.sleep(500);

            solo.waitForActivity("YoConversationActivity");

            for (int i = 0; i <= 5; i++) {
            solo.sleep(90);
            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
            solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 1));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "Internet Status now: "+ YoTestAutomation.OnlineOfflineResult);
            assertTrue(
                    "Wait for image button (id: com.lotd.yoapp.R.id.imagebtnSend) failed.",
            solo.waitForImageButtonById("com.lotd.yoapp.R.id.imagebtnSend", 1));
            solo.clickOnImageButton((ImageButton)
            solo.findViewById("com.lotd.yoapp.R.id.imagebtnSend"));
            solo.sleep(1);
                }
           *//**//* solo.goBack();
            }*//**//*
            solo.goBack();
            solo.sleep(500);*/


        } catch (AssertionFailedError e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        } catch (Exception e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        }
    }
}
