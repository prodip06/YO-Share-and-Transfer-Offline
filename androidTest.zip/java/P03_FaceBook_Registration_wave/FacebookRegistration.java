package P03_FaceBook_Registration_wave;

/**
 * Facebook Registration created by Prodip on 24 Feb, 2016.
 */

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;

import com.bitbar.recorder.extensions.ExtSolo;

import junit.framework.AssertionFailedError;

public class FacebookRegistration extends ActivityInstrumentationTestCase2<Activity> {

    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.lotd.yoapp.YoSplash";
    private static Class<?> launchActivityClass;
    String strInput;

    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private ExtSolo solo;

    @SuppressWarnings("unchecked")
    public FacebookRegistration() {
        super((Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass()
                .getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }

    public void testCase07_SendingHyperlocalTextMessages() throws Exception {
        try {

            solo.waitForActivity("YoSplash");
            solo.sleep(2000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnText("friends");
            solo.sleep(500);

            solo.clickOnText("Register with Facebook");
            solo.sleep(1000);

            solo.waitForActivity("Progressing");
            solo.sleep(9000);

            solo.waitForActivity("MyContacts");
            solo.sleep(500);

         /* View view = solo.getView("profileName");
            solo.clickOnView(view);
            solo.sleep(500);

            solo.waitForActivity("YoConversationActivity");
            for (int i = 0; i <= 3; i++) {
                solo.sleep(900);
                assertTrue(
                        "Wait for edit text (id: com.lotd.yoapp.R.id.editTextSms) failed.",
                solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextSms", 100));
                solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextSms"),"This is Automated Message,Plz dont mind and ignore this message");

                assertTrue(
                        "Wait for image button (id: com.lotd.yoapp.R.id.imagebtnSend) failed.",
                solo.waitForImageButtonById("com.lotd.yoapp.R.id.imagebtnSend", 100));
                solo.clickOnImageButton((ImageButton)
                solo.findViewById("com.lotd.yoapp.R.id.imagebtnSend"));
                solo.sleep(100);
            }
            */

           // solo.waitForActivity("Done");
            solo.clickOnText("DONE");
            solo.sleep(500);

            solo.goBack();

        } catch (AssertionFailedError e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        } catch (Exception e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        }
    }
}
