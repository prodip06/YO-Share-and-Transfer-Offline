package P07_Createclose_Hotspot;

/*
 * Created by Prodip Biswas on 2-Feb-2016.
 **/

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.ImageButton;

import com.bitbar.recorder.extensions.ExtSolo;

import junit.framework.AssertionFailedError;

public class T64Network02_CreateInstantHotspot extends ActivityInstrumentationTestCase2<Activity> {

    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.lotd.yoapp.YoSplash";
    private static Class<?> launchActivityClass;
    String strInput;

    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private ExtSolo solo; // ExtSolo is an extension of Robotium Solo that helps collecting better test execution data during test runs

    @SuppressWarnings("unchecked")
    public T64Network02_CreateInstantHotspot() {
        super((Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass()
                .getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }




    public void testCase07_SendingHyperlocalTextMessages() throws Exception {
        try {

            solo.waitForActivity("YoSplash");
            solo.sleep(2000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            //Click About icon
          /*ImageButton image1 = (ImageButton) solo.getView("imageButton_about");
            solo.clickOnView(image1);
            solo.sleep(1500);*/

            //Click Settins icon
            /*ImageButton image2 = (ImageButton) solo.getView("imageButton_settings");
            solo.clickOnView(image2);
            solo.sleep(1500);*/

            //Click Hotspot icon
            ImageButton image3 = (ImageButton) solo.getView("imageButton_hotspot");
            solo.clickOnView(image3);
            solo.sleep(1500);

            solo.clickOnText("CREATE HOTSPOT");
            solo.sleep(2000);

            solo.clickOnText("CLOSE");
            solo.sleep(15000);

            solo.goBack();


        } catch (AssertionFailedError e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        } catch (Exception e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        }
    }
}
