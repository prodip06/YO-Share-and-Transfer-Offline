package P11_HyperNetContactBlockContact;

/**
 * Created by Prodip Biswas on 28-03-2016
 */

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;

import com.bitbar.recorder.extensions.ExtSolo;

import junit.framework.AssertionFailedError;

public class T14Contact02_01_BlockAndUnblockContact extends ActivityInstrumentationTestCase2<Activity> {

    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.lotd.yoapp.YoSplash";
    private static Class<?> launchActivityClass;

    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private ExtSolo solo; // ExtSolo is an extension of Robotium Solo that helps collecting better test execution data during test runs

    @SuppressWarnings("unchecked")
    public T14Contact02_01_BlockAndUnblockContact() {
        super((Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass()
                .getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }

    public void testCase04_FavoriteContact() throws Exception {
        try {

            solo.waitForActivity("YoSplash");
            solo.sleep(3000);

        /*    solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnText("friends");
            solo.sleep(500);
            solo.clickOnText("friends");
            solo.sleep(500);*/

            int screenWidth = getActivity().getWindowManager().getDefaultDisplay().getWidth();
            int screenHeight = getActivity().getWindowManager().getDefaultDisplay().getHeight();
            int fromX, toX, fromY, toY = 0;
            fromX = screenWidth/2;
            toX = screenWidth/2;
            fromY = (screenHeight/2) + (screenHeight/3);
            toY = (screenHeight/2) - (screenHeight/3);
            int scroll_time = 60000;
            solo.sleep(5000);
            // Drag UP
            solo.drag(fromX, toX, fromY, toY, 40);
            solo.drag(toX, fromX, toY, fromY, 50);
            solo.sleep(8370);



           /* solo.clickOnText("Barun");
            solo.sleep(800);*/


            View view1 = solo.getView("person_img");
            solo.clickOnView(view1);
            solo.sleep(500);

           /* solo.clickOnImageButton(2);
            solo.sleep(2000);*/

            solo.sendKey(solo.MENU);
            solo.sendKey(KeyEvent.KEYCODE_MENU);
            solo.clickOnMenuItem("Block");

   /*       solo.clickOnText("Block");
            solo.sleep(2000);
            solo.goBack();

            solo.sendKey(solo.MENU);
            solo.sendKey(KeyEvent.KEYCODE_MENU);
            solo.clickOnMenuItem("Blocked Users");*/

            solo.goBack();
            solo.sleep(1000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(4500);


            //Click Settins icon
            ImageButton image2 = (ImageButton) solo.getView("imageButton_settings");
            solo.clickOnView(image2);
            solo.sleep(1500);

            solo.clickOnText("Message");
            solo.sleep(500);


            solo.clickOnText("Blocked Users");
            solo.sleep(500);

       /*   View view2 = solo.getView("person_img");
            solo.clickOnView(view2);
            solo.sleep(500);

            solo.sendKey(solo.MENU);
            solo.sendKey(KeyEvent.KEYCODE_MENU);
            solo.clickOnMenuItem("Blocked Users");*/


         // If user want to unblock first user he can do so
            solo.clickOnImage(1);
            solo.sleep(500);

            solo.clickOnText("Unblock");
            solo.sleep(2000);


        } catch (AssertionFailedError e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        } catch (Exception e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        }
    }
}

