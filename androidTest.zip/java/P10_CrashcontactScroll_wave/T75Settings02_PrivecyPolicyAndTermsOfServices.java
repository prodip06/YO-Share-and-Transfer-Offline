package P10_CrashcontactScroll_wave;

/**
 * Created by Prodip on 25-Feb-2016.
 */

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.ImageButton;

import com.bitbar.recorder.extensions.ExtSolo;

import junit.framework.AssertionFailedError;

import TestAutomation.YoTestAutomation;

public class T75Settings02_PrivecyPolicyAndTermsOfServices extends ActivityInstrumentationTestCase2<Activity> {

    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.lotd.yoapp.YoSplash";
    private static Class<?> launchActivityClass;
    String Input;


    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    private ExtSolo solo; // ExtSolo is an extension of Robotium Solo that helps collecting better test execution data during test runs

    @SuppressWarnings("unchecked")
    public T75Settings02_PrivecyPolicyAndTermsOfServices() {
        super((Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass()
                .getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }

    public void testCase24_SettingsViewDataUsage() throws Exception {
        try {

            solo.waitForActivity("YoSplash");
            solo.sleep(3000);

        /*  solo.clickOnScreen(56, 106);
            solo.sleep(3000);*/

            solo.clickOnActionBarHomeButton();
            solo.sleep(3000);

            //Click About icon
            ImageButton image1 = (ImageButton) solo.getView("imageButton_about");
            solo.clickOnView(image1);
            solo.sleep(1500);

            solo.clickOnText("Privacy Policy");
            solo.sleep(510);


            int screenWidth = getActivity().getWindowManager().getDefaultDisplay().getWidth();
            int screenHeight = getActivity().getWindowManager().getDefaultDisplay().getHeight();
            int fromX, toX, fromY, toY = 0;
            fromX = screenWidth/2;
            toX = screenWidth/2;
            fromY = (screenHeight/2) + (screenHeight/3);
            toY = (screenHeight/2) - (screenHeight/ 3);
            int scroll_time = 6000;
            solo.sleep(5000);
            // Drag UP
            solo.drag(fromX, toX, fromY, toY, 40);
            solo.drag(toX, fromX, toY, fromY, 50);
            solo.sleep(5370);

            int screenWidth1 = getActivity().getWindowManager().getDefaultDisplay().getWidth();
            int screenHeight1 = getActivity().getWindowManager().getDefaultDisplay().getHeight();
            int fromX1, toX1, fromY1, toY1 = 0;
            fromX1 = screenWidth1/2;
            toX1 = screenWidth1/2;
            fromY1 = (screenHeight1/2) + (screenHeight1/3);
            toY1 = (screenHeight1/2) - (screenHeight1/ 3);
            int scroll_time1 = 6000;
            solo.sleep(5000);
            // Drag UP
            solo.drag(fromX1, toX1, fromY1, toY1, 40);
            solo.drag(toX1, fromX1, toY1, fromY1, 50);
            solo.sleep(5370);

            solo.goBack();
            solo.sleep(1000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnText("friends");
            solo.sleep(500);

            solo.clickOnText("Bk");
            solo.sleep(500);
            
        /*  View view = solo.getView("profileName");
            solo.clickOnView(view);
            solo.sleep(500);*/

            solo.waitForActivity("MessageActivity");

            for (int i = 0; i <= 1; i++) {
                solo.sleep(90);
                assertTrue(
                "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 1));
                Input = YoTestAutomation.Crash + YoTestAutomation.crashcheck;
                solo.typeText(0, Input);
                assertTrue(
                "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 1));
                solo.clickOnImageButton((ImageButton) solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
                solo.sleep(1);
            }



            } catch (AssertionFailedError e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        }    catch (Exception e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        }
    }

}
