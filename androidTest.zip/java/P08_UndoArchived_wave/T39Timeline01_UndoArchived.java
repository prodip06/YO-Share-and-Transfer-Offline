package P08_UndoArchived_wave;
/**
 * Created by Prodip Biswas on 06-April-2016.
 */

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.bitbar.recorder.extensions.ExtSolo;

import junit.framework.AssertionFailedError;

public class T39Timeline01_UndoArchived extends ActivityInstrumentationTestCase2<Activity> {

    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.lotd.yoapp.YoSplash";
    private static Class<?> launchActivityClass;

    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private ExtSolo solo; // ExtSolo is an extension of Robotium Solo that

    @SuppressWarnings("unchecked")
    public T39Timeline01_UndoArchived() {
        super((Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass()
        .getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }

    public void testCase07_SendingHyperlocalTextMessages() throws Exception {
        try {

            solo.waitForActivity("YoSplash");
            solo.sleep(3000);

            /**
             * solo.clickOnScreen(56, 106);
             * solo.sleep(100);
             */

            solo.clickOnActionBarHomeButton();
            solo.sleep(2000);

            solo.clickOnText("friends");
            solo.sleep(1200);

              // For clicking one contact only
              View view1 = solo.getView("profileName");
              solo.clickOnView(view1);
              solo.sleep(500);

            solo.waitForActivity("MessageActivity");
            for (int i = 0; i <= 2; i++) {
                solo.sleep(90);
                assertTrue(
                        "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                        solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 1000));
                solo.enterText((EditText)
                        solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is Automated Message,Plz dont mind and ignore this message");
                assertTrue(
                        "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                        solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 1000));
                solo.clickOnImageButton((ImageButton)
                        solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
                solo.sleep(1);

            }
                solo.goBack();


            solo.clickOnActionBarHomeButton();
            solo.clickOnText("messages");
            solo.sleep(2000);

        /*  RecyclerView myList = (RecyclerView) solo.getView(R.id.recycler_view);
            View listElement = myList.getChildAt(0);
            solo.sleep(100);*/


            View viewsms = solo.getView("recycler_view");
            solo.sleep(500);

            solo.scrollToSide(solo.LEFT);
            solo.sleep(1000);
            solo.clickOnText("Undo");
            solo.sleep(1000);

            solo.scrollToSide(solo.LEFT);
            solo.sleep(1000);

            solo.sendKey(solo.MENU);
            solo.sendKey(KeyEvent.KEYCODE_MENU);
            solo.clickOnMenuItem("Archived");

            /*
            solo.clickOnImage(2);
            solo.sleep(520);
            **/

            /*
            Edited by Prodip Biswas at 04/02/2016
            **/
            solo.clickOnText(2);
            solo.sleep(520);

            solo.waitForActivity("MessageActivity");
            for (int i = 0; i <= 2; i++) {
                solo.sleep(90);
                assertTrue(
                        "Wait for edit text (id: com.lotd.yoapp.R.id.editTextMessage) failed.",
                solo.waitForEditTextById("com.lotd.yoapp.R.id.editTextMessage", 1000));
                solo.enterText((EditText)
                solo.findViewById("com.lotd.yoapp.R.id.editTextMessage"), "This is Automated Message,Plz dont mind and ignore this message");
                assertTrue(
                        "Wait for image button (id: com.lotd.yoapp.R.id.imageButtonSend) failed.",
                        solo.waitForImageButtonById("com.lotd.yoapp.R.id.imageButtonSend", 1000));
                solo.clickOnImageButton((ImageButton)
                        solo.findViewById("com.lotd.yoapp.R.id.imageButtonSend"));
                solo.sleep(1);

            }
            solo.goBack();


        } catch (AssertionFailedError e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        } catch (Exception e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail",
                    e);
            throw e;
        }
    }
}
