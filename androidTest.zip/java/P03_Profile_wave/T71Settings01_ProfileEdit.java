package P03_Profile_wave;
 /*
 Test Automation by Prodip Biswas 25 Mar,2016
 **/

import android.app.Activity;
import android.test.ActivityInstrumentationTestCase2;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.bitbar.recorder.extensions.ExtSolo;
import com.lotd.yoapp.R;

import junit.framework.AssertionFailedError;

public class T71Settings01_ProfileEdit extends ActivityInstrumentationTestCase2<Activity> {

    private static final String LAUNCHER_ACTIVITY_CLASSNAME = "com.lotd.yoapp.YoSplash";
    private static Class<?> launchActivityClass;

    static {
        try {
            launchActivityClass = Class.forName(LAUNCHER_ACTIVITY_CLASSNAME);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private ExtSolo solo;

    @SuppressWarnings("unchecked")
    public T71Settings01_ProfileEdit() {
        super((Class<Activity>) launchActivityClass);
    }

    @Override
    public void setUp() throws Exception {
        super.setUp();
        solo = new ExtSolo(getInstrumentation(), getActivity(), this.getClass()
                .getCanonicalName(), getName());
    }

    @Override
    public void tearDown() throws Exception {
        solo.finishOpenedActivities();
        solo.tearDown();
        super.tearDown();
    }


    public void testCase_ViewAndEditProfile() throws Exception {
        try {
            solo.waitForActivity("YoSplash");
            solo.sleep(2000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnActionBarHomeButton();
            solo.sleep(1000);

            solo.clickOnScreen(56, 106);
            solo.sleep(2000);

        /*  solo.clickOnScreen(56, 106);
            solo.sleep(2000);*/


           //Code added 24/02/2016
            solo.sendKey(solo.MENU);
            solo.sendKey(KeyEvent.KEYCODE_MENU);

            
            solo.clickOnMenuItem("Edit Profile");
            solo.sleep(100);



        /*  solo.clickOnText(2);
            solo.sleep(520);
            solo.clickOnImageButton(2);
            solo.sleep(1000);
            solo.clickOnText("Edit Profile");*/


            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.text_nof_letter) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.text_nof_letter", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.txt_name"), "PRODIP");

            assertTrue(
                    "Wait for edit text (id: com.lotd.yoapp.R.id.textView_fullName) failed.",
                    solo.waitForEditTextById("com.lotd.yoapp.R.id.textView_fullName", 200));
            solo.enterText((EditText) solo.findViewById("com.lotd.yoapp.R.id.editTextView_fullName"), "Prodip Kumar Biswas");

            View v = solo.getView(R.id.txt_gender);
            solo.clickOnView(v);
            solo.clickOnButton((Button) solo.findViewById("com.lotd.yoapp.R.id.male"));
            solo.sleep(1000);
            solo.clickOnText("OK");
            solo.sleep(1000);

            View birth = solo.getView(R.id.txt_birthday);
            solo.clickOnView(birth);
            solo.clickOnText("Done");
            //solo.clickOnText("OK");
            solo.sleep(1500);

            solo.clickOnView(solo.getView(R.id.itemEdit));
            solo.sleep(5000);
            solo.goBack();
        }
          catch (AssertionFailedError e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail", e);
            throw e;
        } catch (Exception e) {
            solo.fail(
                    "com.lotd.yoapp.test.YoSplashTest3.testRecorded_scr_fail", e);
            throw e;
        }
    }
}

