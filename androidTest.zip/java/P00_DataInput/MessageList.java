package P00_DataInput;

/**
 * Created by W3E-2 on 29-May-15.
 */
public class MessageList {

    public static String welcome=" Welcome YO Android Test Automation ";

    public static String TestCase="You Are Running TestCase";


    }
