package P00_DataInput;
/**
 * Created by W3E-2 on 03-Jun-15.
 */
public class DataInput {

    public static String PhoneNumber= "01985953726"; //Put Phone Number Here
    public static String VoiceTestNumber="01717757902";
    public static String Code= "6666";
    public static String ProfileName="Automator";
    public static String SecondDeviceProfileName="ASAD";//Make Second Device Name and Save
    // Second Device Number Saved in Phonebook

    public static int hyperlocalFriends =2; //Check Your HyperLocal Friend Status before Running TC
    public static int internetFriends=2;    //Check Your Internet Friend Status before Running TC

    public static String VersionName="1.4.0";

    //Switch to a open WiFi network
    public static String OpenWifiNetwork="YO-Adnan";

    //Switch to a protected (WPA/WPA2) WiFi network
    public static String ProtectedWifiNetwork="YO!";
    public static String ProtectedWifiNetwork2="W3ENGINEERS";
    //Create an instant hotspot


}

